/* 
 * File:   timer0.h
 * Author: LENOVO
 *
 * Created on December 15, 2023, 10:08 PM
 */

#ifndef TIMER0_H
#define	TIMER0_H

void init_timer0(void);

#endif