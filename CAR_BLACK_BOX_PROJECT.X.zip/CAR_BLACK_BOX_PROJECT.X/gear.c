/*
 * File:   gear.c
 * Author: LENOVO
 *
 * Created on December 14, 2023, 9:17 AM
 */


#include <xc.h>
#include "clcd.h"

void gear(int g)
{
   /* if(g==1)
    {
        clcd_print("GR  ", LINE2(9));
    }
    else if(g==2)
    {
        clcd_print("GN  ", LINE2(9));
    }
    else if(g==3)
    {
        clcd_print("G1  ", LINE2(9));
    }
    else if(g==4)
    {
        clcd_print("G2  ", LINE2(9));
    }
    else if(g==5)
    {
        clcd_print("G3  ", LINE2(9));
    }
    else if(g==6)
    {
        clcd_print("G4  ", LINE2(9));
    }
     */
   
     
     
     
        
}
